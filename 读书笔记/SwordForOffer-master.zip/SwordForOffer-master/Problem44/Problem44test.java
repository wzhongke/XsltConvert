package Problem44;

public class Problem44test {
	public static void main(String args[])
	{
		IsContinuous test=new IsContinuous();
		int[] array={0,4,6,9,0};
		System.out.println(test.isContinuous(array));
	}

}
