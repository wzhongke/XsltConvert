package Problem32;

public class Problem32 {
	public static void main(String args[])
	{
		NumberOf1Between1AndN testAndN=new NumberOf1Between1AndN();
		System.out.println(testAndN.CountOne1(999999));
		System.out.println(testAndN.CountOne2(999999));
	}

}
