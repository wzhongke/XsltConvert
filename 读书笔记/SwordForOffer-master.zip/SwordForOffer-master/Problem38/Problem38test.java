package Problem38;

public class Problem38test {
	public static void main(String args[])
	{
		int[] testArray={1,2,5,6,6,7};
		GetNumberOfK test=new GetNumberOfK();
		System.out.println(test.getNumberOfK(testArray,0));
	}
}
