package Problem42;

public class Problem42test {
	public static void main(String args[])
	{
		ReverseSentence test=new ReverseSentence();
		test.leftRotateString("abcdefg",7);
	}

}
