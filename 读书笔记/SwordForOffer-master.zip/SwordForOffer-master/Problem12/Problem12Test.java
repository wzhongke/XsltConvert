
package Problem12;

public class Problem12Test {
	public static void main(String args[])
	{
		PrintToMaxOfNDigits test=new PrintToMaxOfNDigits();
		test.printToMaxOfNDigits(3);
	}
	

}

	