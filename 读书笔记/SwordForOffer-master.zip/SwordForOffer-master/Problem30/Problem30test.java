package Problem30;

public class Problem30test {
	public static void main(String args[])
	{
		GetLeastNumbers test=new GetLeastNumbers();
		int[] array={4,5,1,6,2,7,3,2};
		test.getLeastNumbers(array,-1);
	}

}
