package Problem46;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

public class Problem46test {
	public static void main(String args[]) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException  
	{
		Calculate tCalculate=new Calculate();
		System.out.println(tCalculate.sum(100));

	}
}
