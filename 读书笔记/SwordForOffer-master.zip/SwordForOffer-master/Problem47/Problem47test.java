package Problem47;

public class Problem47test {
	public static void main(String args[])
	{
		Add test=new Add();
		System.out.println(test.add(5, 13));
	}

}
