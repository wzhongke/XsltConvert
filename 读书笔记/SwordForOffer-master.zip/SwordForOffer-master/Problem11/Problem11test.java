package Problem11;

/**
 * Created by liujia on 14-8-27.
 */
public class Problem11test {
	public static void main(String args[]) throws  Exception{
		Power test = new Power();
		System.out.println(test.power(2,10));
	}
}
