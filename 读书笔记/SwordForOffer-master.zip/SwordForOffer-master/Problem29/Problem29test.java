package Problem29;

public class Problem29test {
	public static void main(String args[])
	{
		int[] array={1};
		MoreThanHalfNum test=new MoreThanHalfNum();
		System.out.println(test.moreThanHalfNum(array));
		
	}

}
