package Problem4;

/**
 * Created by liujia on 14-8-25.
 */
public class Problem4test {
	public static void main(String args[])
	{
		ReplaceBlank test=new ReplaceBlank();
		String s="  ";
		System.out.println(test.replaceBlank(s));
	}
}
