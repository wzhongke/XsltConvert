package Problem34;

public class Problem34test {
	public static void main(String args[])
	{
		UglyNumber test=new UglyNumber();
		System.out.println(test.getUglyNumber(1500));
	}

}
