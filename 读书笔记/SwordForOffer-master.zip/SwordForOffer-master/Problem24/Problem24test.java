package Problem24;

public class Problem24test {
	public static void main(String args[])
	{
		int[] array={1,2,3,4};
		VerifySequerceOfBST test=new VerifySequerceOfBST();
		System.out.println(test.verifySequenceOfBST(array));
	}

}
