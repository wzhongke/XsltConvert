package problem36;

public class Problem36test {
	public static void main(String args[])
	{
		int[] array={4,3,2,1};
		InversePairs test=new InversePairs();
		System.out.println(test.inversePairs(array));
	}

}
