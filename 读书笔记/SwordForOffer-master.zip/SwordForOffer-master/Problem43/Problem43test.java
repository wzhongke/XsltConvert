package Problem43;

public class Problem43test {
	public static void main(String args[])
	{
		DicesProbability test=new DicesProbability();
		test.printProbability(2);
	}

}
