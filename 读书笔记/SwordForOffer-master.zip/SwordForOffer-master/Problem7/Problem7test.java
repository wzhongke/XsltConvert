package Problem7;

/**
 * Created by liujia on 14-8-26.
 */
public class Problem7test {
	public static void main(String args[]) throws Exception
	{
		CQueue test=new CQueue();
		test.appendTail("1");
		test.appendTail("1");
		test.deleteHead();
	}
}
