package Problem9;

/**
 * Created by liujia on 14-8-27.
 */
public class Problem9test {
	public static void main(String args[])
	{
		Fibonacci test=new Fibonacci();
		System.out.println(test.fibonacci(50));
	}

}
