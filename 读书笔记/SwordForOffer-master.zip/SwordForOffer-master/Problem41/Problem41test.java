package Problem41;

public class Problem41test {
	public static void main(String args[])
	{
		FindNumbersWithSum test=new FindNumbersWithSum();
		int[] array={1,2,4,7,11,15};
		test.findContinuousSequence(15);
	}

}
