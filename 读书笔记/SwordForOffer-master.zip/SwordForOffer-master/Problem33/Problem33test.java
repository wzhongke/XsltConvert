package Problem33;

public class Problem33test {
	public static void main(String args[])
	{
		PrintMinNumber test=new PrintMinNumber();
		int[] array={3,3,32};
		test.printMin(array);
	}

}
