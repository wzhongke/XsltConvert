package Problem31;

public class Problem31 {
	public static void main(String args[])
	{
		int[] array={1,-2,3,10,-4,7,2,-5};
		FindGreatestSum test=new FindGreatestSum();
		System.out.println(test.findGreatestSum(array));
	}

}
