package Problem20;

public class Problem20test {
	public static void main(String args[])
	{
		int[][] array={
				{1},
				};
		PrintMatrixInCircle testCircle=new PrintMatrixInCircle();
		testCircle.printMatrixInCircle(array);
	}

}
