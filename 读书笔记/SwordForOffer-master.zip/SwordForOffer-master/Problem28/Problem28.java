package Problem28;

public class Problem28 {
	public static void main(String args[])
	{
		Permutation testPermutation=new Permutation();
		testPermutation.permutation("abc");
	}

}
