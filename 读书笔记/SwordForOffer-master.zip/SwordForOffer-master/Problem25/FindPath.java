package Problem25;

import java.util.Stack;

public class FindPath {
	/*
	 * 输入一个二叉树和一个整数，打印出二叉树中节点值的和为输入整数的所有路径
	 */
	public static void findPath(BinaryTreeNode root, int k) {
		if (root == null)
			return;
		Stack<Integer> path = new Stack<Integer>();
		int currentSum = 0;
		findPath(root, k, path, currentSum);

	}

	 public static void findPath(BinaryTreeNode root, int expectSum, Stack<Integer> stack,  int currentSum) {
		if (root == null) {
			return;
		}
		// 把当前结点进栈
		stack.push(root.data);
		currentSum += root.data;
		// 如果是叶子结点，而且和为给定的值，则打印路径
		boolean isLeaf = root.leftNode == null && root.rightNode == null;
		if (isLeaf && currentSum == expectSum) {
			for (Integer e : stack) {
				System.out.print(e + " ");
			}
			System.out.println();
		}

		// 如果不是叶子结点，则遍历它的子结点
		if (root.leftNode != null) {
			findPath(root.leftNode, expectSum, stack, currentSum);
		}
		if (root.rightNode != null) {
			findPath(root.rightNode, expectSum, stack, currentSum);
		}
		// 在返回到父结点之前，在路径上删除当前结点
		stack.pop();
	} 
}
class BinaryTreeNode 
{
	int data;
	BinaryTreeNode leftNode;
	BinaryTreeNode rightNode;
}