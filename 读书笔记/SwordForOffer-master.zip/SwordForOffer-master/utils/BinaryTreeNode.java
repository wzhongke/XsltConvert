package utils;

/**
 * Created by liujia on 14-8-26.
 */
public class BinaryTreeNode {
	public int value;
	public BinaryTreeNode leftNode;
	public BinaryTreeNode rightNode;
}
