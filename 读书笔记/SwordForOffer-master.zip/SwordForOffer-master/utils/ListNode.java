package utils;

/**
 * Created by liujia on 14-8-26.
 */
public class ListNode {
		public int data;
		public ListNode next;

}
