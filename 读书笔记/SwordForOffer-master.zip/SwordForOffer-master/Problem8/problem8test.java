package Problem8;

public class problem8test {
	public static void main(String args[])
	{
		Min testMin=new Min();
		int[] array={1,1,1,2,0};
		System.out.println(testMin.minInReversingList(array));
	}

}
