package Problem10;

/**
 * Created by liujia on 14-8-27.
 */
public class Problem10test {
	public static void main(String args[])
	{
		NumberOf1 test=new NumberOf1();
		System.out.println(test.numberOf1(-11));

	}

}
