package Problem45;

public class Problem45test {
	public static void main(String args[]) {
		LastRemaining tesLastRemaining=new LastRemaining();
		int s=tesLastRemaining.lastRemaining(5,1);
		System.out.println(s);

	}
	
	

}
