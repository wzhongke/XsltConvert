package Problem40;

public class Problem40test {
	public static void main(String args[])
	{
		FindNumsAppearOnce test=new FindNumsAppearOnce();
		int[] array={4,6,1,1,1,1};
		test.findNumsAppearOnce(array);
	}

}
